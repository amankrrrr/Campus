# Campus Unlocked

For running the code:
Go to folder and type npm start in terminal.

For starting background server:
Go to folder source and then type node or nodemon app in terminal by running it as administrator.

For now everything is running on local host.
